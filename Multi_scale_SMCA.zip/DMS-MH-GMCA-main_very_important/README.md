# DMS-MH-GMCA

python -m torch.distributed.launch --master_port=4234  --nproc_per_node=8 --use_env main.py --coco_path ../../../dataset/coco/ --batch_size 1 --lr_drop 100 --num_queries 300 --epochs 150 --dynamic_scale type3  --enc_layers 5 --dim_feedforward 1024 --output_dir DMS_MH_GMCA_150


8 GPU 50 epoch resnet 101
python -m torch.distributed.launch --master_port=4234  --nproc_per_node=8 --use_env main.py --coco_path ../../../dataset/coco/ --batch_size 1 --lr_drop 40 --num_queries 300 --epochs 50 --dynamic_scale type3  --enc_layers 5 --dim_feedforward 1024 --output_dir DMS_MH_GMCA_50epoch_resnet101 --backbone resnet101
